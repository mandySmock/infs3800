<html>
<head>
<title>Main Menu</title>
</head>

<body>

<?php
session_start();

//Unsure how to display $un as user input from LoginHandler.php
$un = 'jma';

  if (!(isset($_SESSION['authorized']) && $_SESSION['authorized'])) {
	session_destroy();
	echo "Error <a href=\"Login.html\">Return to Login</a>" ;
	header('url=Login.html') ;
  }
  else {
	echo "Hello " . $un;
  }
  
?>

</body>
</html>