<html>
<head>
<title>Handler</title>
</head>

<body>
<?php
	session_start();
?>

<?php
$un = $_POST['user'];
$pw = $_POST['pswd'];

echo "User Name: " . $un . "<br>";
echo "Password: " . $pw . "<br>";

	if ($un == 'jma' && $pw=='jm123') {
		$_SESSION['authorized'] = true;
		$_SESSION['user'] = "jma";

	 echo "<br>Login Successful. <a href=\"MainMenu.php\">Go to Main Menu</a>" ;
	 header('url=MainMenu.php');
  }
	else {
		session_destroy();
		echo "<br>Login Failure. <a href=\"Login.html\">Return to Login</a>" ;
		header('url=Login.html');
  }
	

?>

</body>
</html>