DROP USER IF EXISTS 'joe'@'localhost';
DROP USER IF EXISTS 'root'@'localhost';
DROP DATABASE IF EXISTS `INFS3800Project`;

CREATE DATABASE IF NOT EXISTS `INFS3800Project`;

USE `INFS3800Project`;

CREATE TABLE IF NOT EXISTS `login` (
  `user` varchar(50) PRIMARY KEY,
  `pswd` varchar(50) NOT NULL
);

INSERT INTO `login` 
(`user`, `pswd`) 
VALUES
	('jma', 'jma123'),
	('jack', 'jack123'),
	('jeff', 'jeff123'),
	('jane', 'jane123'),
	('joe', 'joe123');
	
CREATE TABLE IF NOT EXISTS `makeup` (
	`brand` varchar(50) PRIMARY KEY,
	`product` varchar(50) NOT NULL,
	`product_type` varchar(50) NOT NULL,
	`price` int NOT NULL
);

INSERT INTO `makeup`
(`brand`,`product`,`product_type`,`price`)
VALUES
	('Fitglow Beauty', 'Foundation+', 'Foundation', 55.00),
	('Westman Atelier', 'Eye Pods', 'Eyeshadow', 88.00),
	('Ilia', 'Clean Line Gel Liner', 'Eyeliner', 26.00),
	('Iris&Romeo', 'Ceramide Multi-Balm', 'Blush', 29.00),
	('Pai', 'The Impossible Glow', 'Bronzer', 39.00);
	
CREATE TABLE IF NOT EXISTS `skincare` (
	`brand` varchar(50) PRIMARY KEY,
	`product` varchar(50) NOT NULL,
	`product_type` varchar(50) NOT NULL,
	`price` int NOT NULL
);

INSERT INTO `skincare`
(`brand`,`product`,`product_type`,`price`)
VALUES
	('Ursa Major', 'Fantastic Face Wash', 'Cleanser', 32.00),
	('Osea', 'Atmosphere Protection Cream', 'Moisturizer', 54.00),
	('Tata Harper', 'Hydrating Floral Essence', 'Toner', 76.00),
	('Pai', 'Viper Gloss', 'Face Oil', 89.00),
	('Indie Lee', 'Banish Solution', 'Blemish Treatment', 21.00);
	
CREATE TABLE IF NOT EXISTS `haircare` (
	`brand` varchar(50) PRIMARY KEY,
	`product` varchar(50) NOT NULL,
	`product_type` varchar(50) NOT NULL,
	`price` int NOT NULL
);

INSERT INTO `haircare`
(`brand`,`product`,`product_type`,`price`)
VALUES
	('Innersense Organic Beauty', 'Hydrating Cream Hairbath', 'Shampoo', 28.00),
	('Captain Blankenship', 'Texture Sea Salt Spray', 'Styling', 29.00),
	('Reverie', 'Ever Recovery Oil', 'Hair Treatment', 52.00),
	('Ceremonia', 'Guava Rescue Spray', 'Hair Treatment', 22.00),
	('Evolvh', 'WonderBalm', 'Styling', 59.00);
	
CREATE USER 'root'@'localhost';
GRANT ALL PRIVILEGES ON `INFS3800Project`.* TO 'root'@'localhost';
FLUSH PRIVILEGES;

CREATE USER 'joe'@'localhost' IDENTIFIED BY 'joe123';
GRANT ALL PRIVILEGES ON `INFS3800Project`.* TO 'joe'@'localhost';
FLUSH PRIVILEGES;