<html>
<head>
<title>Validate Login | UltimateYou</title>

<link rel="stylesheet" href="ProjectStyle1.css">	
</head>

<body>
You Entered:<br><br>

<?php
$un = $_POST['user'];
$pw = $_POST['pswd'];
$query = " SELECT * FROM login WHERE user = '$un' AND pswd = '$pw' ; " ; 

echo "User Name: " . $un ;
echo "<br>" ;
echo "Password : " . $pw ;
echo "<br>" ;
echo "Query Statement: " . $query ;
echo "<br><br>" ;

include 'Checkpoint3_Connection.php' ;

if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, $query);

$row = mysqli_fetch_array($result);

if ($row == null) 
{
	echo "Login Failure<br><br>" ;
	header ('refresh:3; url=Checkpoint3_LoginFailure.html');
}
else 
{
	echo "Login Successful<br><br>" ;	
}

mysqli_close($con); 
?>

</body>
</html>