Final Project Readme:

- Welcome page provides access to login function and 3 beginner beauty guides: Makeup, Skin Care, and Hair
	-Login function is accessed by clicking link in header menu
	-Beauty guides are accessed by clicking respective links under the images in table menu
	
- Main Menu is accessible after successful login
	-Credentials: Username = jma and Password = jma123
	-Unsuccessful login takes user to login failure page with a link to return to the login page
	
- Search function is accessed by clicking link in header menu of Main Menu
	-Products are searchable by product type (e.g., Shampoo, Moisturizer, Foundation)
	-Results are displayed on the next page in a table