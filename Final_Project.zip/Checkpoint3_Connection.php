<?php
$con = mysqli_connect("127.0.0.1","root","","INFS3800Project");
?>